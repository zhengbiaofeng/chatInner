module.exports=[60188,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_users_%5B%5B___path%5D%5D_route_actions_07.n9jl.js.map