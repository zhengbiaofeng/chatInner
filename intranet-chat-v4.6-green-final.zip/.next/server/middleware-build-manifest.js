globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/pkO03RK0JbB_T6CkXvbIr/_buildManifest.js",
    "static/pkO03RK0JbB_T6CkXvbIr/_ssgManifest.js",
    "static/pkO03RK0JbB_T6CkXvbIr/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0~d6ts6h4sj07.js",
    "static/chunks/02i7dfk78~t~2.js",
    "static/chunks/0bmpc66o4m-9z.js",
    "static/chunks/0cj37tl-sc0gx.js",
    "static/chunks/turbopack-08c6kd-_2cwri.js"
  ]
};
