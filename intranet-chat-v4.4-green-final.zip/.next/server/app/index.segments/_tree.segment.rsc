:HL["/_next/static/chunks/04bmkmm9o.w0n.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}},"staleTime":300,"buildId":"S_4wJRXF3_BZwVgV0DWei"}
