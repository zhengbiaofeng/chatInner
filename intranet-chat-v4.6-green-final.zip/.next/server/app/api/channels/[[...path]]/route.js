var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/channels/[[...path]]/route.js")
R.c("server/chunks/[root-of-the-server]__0wm8nio._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_0giojy.._.js")
R.c("server/chunks/_next-internal_server_app_api_channels_[[___path]]_route_actions_0e6vxed.js")
R.m(10051)
module.exports=R.m(10051).exports
