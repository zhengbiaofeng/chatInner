@echo off
chcp 65001 >nul
title NEXUS.CHAT 内网绿色终端

echo =======================================================
echo.
echo           NEXUS.CHAT 赛博终端 - 免安装完全离线版
echo.
echo =======================================================
echo.
echo 正在启动核心服务器...
echo.
echo 提示：按 Ctrl+C 可以随时关闭服务器
echo.

set NODE_ENV=production
set PORT=3000
set HOSTNAME=0.0.0.0

.\bin\node.exe server.js

pause
