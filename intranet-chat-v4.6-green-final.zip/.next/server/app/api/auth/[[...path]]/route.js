var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[[...path]]/route.js")
R.c("server/chunks/[root-of-the-server]__0vml8sk._.js")
R.c("server/chunks/node_modules_bcryptjs_index_0bjz0ul.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_0giojy.._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_[[___path]]_route_actions_0r~8s8x.js")
R.m(19175)
module.exports=R.m(19175).exports
