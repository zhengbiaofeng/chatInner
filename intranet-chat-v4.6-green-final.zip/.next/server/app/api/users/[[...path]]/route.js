var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/users/[[...path]]/route.js")
R.c("server/chunks/[root-of-the-server]__063inlp._.js")
R.c("server/chunks/node_modules_bcryptjs_index_0bjz0ul.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_0giojy.._.js")
R.c("server/chunks/_next-internal_server_app_api_users_[[___path]]_route_actions_07.n9jl.js")
R.m(48461)
module.exports=R.m(48461).exports
