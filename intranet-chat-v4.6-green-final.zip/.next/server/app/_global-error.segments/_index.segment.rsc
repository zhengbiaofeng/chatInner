1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/0bn7sb9dt40_4.js"],"default"]
3:I[37457,["/_next/static/chunks/0bn7sb9dt40_4.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"pkO03RK0JbB_T6CkXvbIr"}
