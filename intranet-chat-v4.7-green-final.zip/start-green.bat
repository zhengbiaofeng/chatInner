@echo off
title NEXUS.CHAT Server
echo =======================================================
echo.
echo           NEXUS.CHAT - OFFLINE STANDALONE
echo.
echo =======================================================
echo.
echo Starting core server...
echo Press Ctrl+C to stop.
echo.

set NODE_ENV=production
set PORT=3000
set HOSTNAME=0.0.0.0

.\bin\node.exe server.js
pause
