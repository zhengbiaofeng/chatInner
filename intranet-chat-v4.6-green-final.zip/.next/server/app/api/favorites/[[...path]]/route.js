var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/favorites/[[...path]]/route.js")
R.c("server/chunks/[root-of-the-server]__0ty~rue._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_0giojy.._.js")
R.c("server/chunks/_next-internal_server_app_api_favorites_[[___path]]_route_actions_02ebl4q.js")
R.m(89625)
module.exports=R.m(89625).exports
