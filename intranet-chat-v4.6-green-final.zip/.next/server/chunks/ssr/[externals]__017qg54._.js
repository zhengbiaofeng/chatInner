module.exports=[24361,(a,b,c)=>{b.exports=a.x("util",()=>require("util"))},22734,(a,b,c)=>{b.exports=a.x("fs",()=>require("fs"))},54799,(a,b,c)=>{b.exports=a.x("crypto",()=>require("crypto"))},88947,(a,b,c)=>{b.exports=a.x("stream",()=>require("stream"))},874,(a,b,c)=>{b.exports=a.x("buffer",()=>require("buffer"))}];

//# sourceMappingURL=%5Bexternals%5D__017qg54._.js.map