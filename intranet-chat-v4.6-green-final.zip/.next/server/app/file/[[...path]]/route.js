var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/file/[[...path]]/route.js")
R.c("server/chunks/[root-of-the-server]__0k3~ubk._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_file_[[___path]]_route_actions_0zav5w9.js")
R.m(47423)
module.exports=R.m(47423).exports
