var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/upload/[[...path]]/route.js")
R.c("server/chunks/[root-of-the-server]__0jc--18._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_0giojy.._.js")
R.c("server/chunks/_next-internal_server_app_api_upload_[[___path]]_route_actions_075f6r9.js")
R.m(27544)
module.exports=R.m(27544).exports
