var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/messages/[[...path]]/route.js")
R.c("server/chunks/[root-of-the-server]__05vmkfe._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_0giojy.._.js")
R.c("server/chunks/_next-internal_server_app_api_messages_[[___path]]_route_actions_0cdrivc.js")
R.m(36475)
module.exports=R.m(36475).exports
