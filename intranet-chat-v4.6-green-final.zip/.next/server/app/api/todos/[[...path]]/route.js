var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/todos/[[...path]]/route.js")
R.c("server/chunks/[root-of-the-server]__07jm849._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_0giojy.._.js")
R.c("server/chunks/_next-internal_server_app_api_todos_[[___path]]_route_actions_0innbm2.js")
R.m(69687)
module.exports=R.m(69687).exports
